import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import 'package:meals/screens/tabs.dart';

// main.dart

final ThemeData theme = ThemeData(
  useMaterial3: true,
  colorScheme: ColorScheme.fromSeed(
    brightness: Brightness.light,
    seedColor: Colors.deepOrange, // Your primary brand color
    surface: Colors.white,
    onSurface: Colors.black87,
    primary: Colors.deepOrange,
    secondary: Colors.amber,
  ),
  scaffoldBackgroundColor: const Color.fromARGB(255, 250, 250, 250), // Off-white background
  appBarTheme: const AppBarTheme(
    backgroundColor: Colors.deepOrange,
    foregroundColor: Colors.white, // Ensures text/icons are white on the orange bar
    elevation: 0,
  ),
  textTheme: GoogleFonts.ralewayTextTheme().copyWith(
    titleLarge: GoogleFonts.robotoCondensed(
      fontWeight: FontWeight.bold,
      color: Colors.black87,
    ),
    bodyLarge: const TextStyle(color: Color.fromRGBO(20, 51, 51, 1)),
    bodyMedium: const TextStyle(color: Color.fromRGBO(20, 51, 51, 1)),
  ),
);

void main() {
  runApp(const App());
}

class App extends StatelessWidget {
  const App({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: theme,
      home: const TabsScreen(),
    );
  }
}
